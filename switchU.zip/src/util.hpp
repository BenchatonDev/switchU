#pragma once

#include <string>

#define SD_CARD_PATH "fs:/vol/external01/"

extern std::string ACCOUNT_ID;

void get_user_information();