# SwitchU
A remake of the Nintendo Switch's UI for the Wii U

## Controls
- `L Stick`: move around the menu

## Building
### Dependencies
- [wut](https://github.com/devkitPro/wut)
- [librpxloader](https://github.com/wiiu-env/librpxloader)
- SDL2 Wii U
- SDL2 image Wii U

Install Devkitpro following [the official guide for your OS](https://devkitpro.org/wiki/Getting_Started)

Install wut:
```
(sudo) (dkp-)pacman -Syu --needed wiiu-dev
```

Install SDL2 Wii U:
```
(sudo) (dkp-)pacman -S wiiu-sdl2 wiiu-sdl2_image
```

### Compiling
Simply run `make` at the root of the repo
```
make (path to Makefile)
```

# Credits
- [DanielKO] For emotional support and helping me figure out the rpx loader
- [BenchatonDev](https://github.com/BenchatonDev) Made the original repository I built this project on.
- [Ashquarky](https://github.com/ashquarky) For porting SDL2 to Wii U
- [Dimok](https://github.com/dimok789) For making VPADInput.h and WPADInput.h
- [GaryOderNichts](https://github.com/GaryOderNichts) For making Wii U ident which I used as 'base'
